<div class="alert alert-danger col-sm-8 mx-auto" style="margin-top:10%;margin-bottom:10%;">
<div class="row">
    <div class="col-sm">
        <img src="./img/semfund.png" class="img-fluid"/>
    </div>
    <div class="col-md">
        <h4 class="alert-heading"><br/>ERROR 404!</h4>
        <p>A Pagina indicada não existe!<br/>Verifique se a URL foi digitada corretamente!</p>
        <p class="mb-0"><a href="?page=home" class="alert-link"> Clique aqui</a> para voltar a página inicial.</p>
    </div>
</div>
</div>