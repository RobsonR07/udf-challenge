<?php


//conexão com o banco de dados
$host = "localhost";
$user = "root";
$pass = "";
$db   = "udf-challenge";

$conn = new mysqli($host, $user, $pass, $db);
?>